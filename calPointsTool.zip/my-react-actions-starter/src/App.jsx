import React from 'react'

export default function App() {
  return (
    <main style={{fontFamily:'system-ui, sans-serif', padding:'2rem'}}>
      <h1>React + Vite + GitHub Actions</h1>
      <p>If you can see this, your local setup works 🎉</p>
    </main>
  )
}
