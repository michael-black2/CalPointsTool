import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// NOTE: If deploying to https://<user>.github.io/<repo>,
// set base to '/<repo>/' below (replace <repo>)
export default defineConfig({
  plugins: [react()],
  // base: '/<repo>/'   // uncomment and set when using GitHub Pages with a repo subpath
})
